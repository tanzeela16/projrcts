package bank.management.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class MiniStatement extends JFrame  implements ActionListener{
    
    JButton  previous;
    String pinnumber;
    MiniStatement(String pinnumber)
    {
        this.pinnumber=pinnumber;
        
        setLayout(null);
        
         setTitle("Mini Statement");
         
         ImageIcon logo1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
         Image logo2=logo1.getImage().getScaledInstance(70,70,Image.SCALE_DEFAULT);
         ImageIcon logo3=new ImageIcon(logo2);
         JLabel logo4=new JLabel(logo3);
         logo4.setBounds(140,10,250,250);
         add(logo4);
         
        JLabel text=new JLabel("Master Bank");
        text.setFont(new Font("Osward",Font.BOLD,30));
        text.setBounds(310,80,1000,100);
        add (text);
        
        JLabel slogan =new JLabel("Master your finances with Bank Master");
        slogan.setFont(new Font("Osward",Font.ITALIC,7));
        slogan.setBounds(330,130,800,45);
        add (slogan);
        
        JLabel transection = new JLabel("Mini Statement");
        transection.setFont(new Font("Osward",Font.BOLD,20));
        transection.setBounds(500,150,300,50);
        add(transection);
        
        JLabel card = new JLabel("Card No:");
        card.setFont(new Font("Osward",Font.BOLD,20));
        card.setBounds(400,190,500,50);
        add(card);
        
        JLabel mini = new JLabel();
        mini.setFont(new Font("Osward",Font.BOLD,20));
        mini.setBounds(400,200,700,250);
        add(mini);
        
        try{
            Conn conn=new Conn( );
            ResultSet rs=conn.s.executeQuery("select * from login where pin='"+pinnumber+"'");
            
            while(rs.next())
            {
                card.setText("Card Number: "+rs.getString("cardNo").substring(0,5)+"XXXXXXXX"+rs.getString("cardNo").substring(12,16));
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
         try{
            Conn conn=new Conn( );
            ResultSet rs=conn.s.executeQuery("select * from bank where pin='"+pinnumber+"'");
            
            while(rs.next())
            {
                mini.setText(mini.getText()+"<html>"+rs.getString("date")+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+rs.getString("status")+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+rs.getString("amount")+"<br><br><html>");
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
          previous=new JButton("Back");
        previous.setBounds(480,475,150,30);
        previous.addActionListener(this);
        add(previous);
        
        JLabel rights=new JLabel("Copyright © 2023 All Rights Reserved");
         rights.setFont(new Font("Osward",Font.ITALIC,10));
        rights.setBounds(400,550,800,45);
        add (rights);
        
        getContentPane().setBackground(Color.WHITE);
         
         
        setSize(1375,750);
        setVisible(true);
        setLocation(0,0); 
        
    }
     public void actionPerformed(ActionEvent ae)
    {
       if(ae.getSource()==previous)
       {
           setVisible(false);
           new Transections(pinnumber).setVisible(true);
           
       }
        
    }
    public static void main(String args[])
    {
    new MiniStatement("");
}
}
