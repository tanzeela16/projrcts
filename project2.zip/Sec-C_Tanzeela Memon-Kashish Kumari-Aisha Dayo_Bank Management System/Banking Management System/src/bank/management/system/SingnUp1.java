
package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SingnUp1 extends JFrame  implements ActionListener{
    JButton previous,next;
    SingnUp1()
    {
       setTitle("Login");
        
         setLayout(null);
         
         ImageIcon logo1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
         Image logo2=logo1.getImage().getScaledInstance(70,70,Image.SCALE_DEFAULT);
         ImageIcon logo3=new ImageIcon(logo2);
         JLabel logo4=new JLabel(logo3);
         logo4.setBounds(140,10,250,250);
         add(logo4);
         
        JLabel text=new JLabel("Master Bank");
        text.setFont(new Font("Osward",Font.BOLD,30));
        text.setBounds(310,80,1000,100);
        add (text);
        
        JLabel slogan =new JLabel("Master your finances with Bank Master");
        slogan.setFont(new Font("Osward",Font.ITALIC,7));
        slogan.setBounds(330,130,800,45);
        add (slogan);
        
        JLabel text2=new JLabel("Accoun Details:");
        text2.setFont(new Font("Osward",Font.BOLD,20));
        text2.setBounds(500,150,1000,100);
        add (text2);
        
        
        
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/login.png"));
        Image i2=i1.getImage().getScaledInstance(25,25,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel label=new JLabel(i3);
        label.setBounds(470,190,25,25);
        add(label);
         
        /*
        
        */
        // ImageIcon login1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpeg"));
         //Image login2=login1.getImage().getScaledInstance(200,200,Image.SCALE_DEFAULT);
         //ImageIcon login3=new ImageIcon(login2);
         //JLabel label2=new JLabel(login3);
         //label2.setBounds(275,150,200,200);
        // add(label2);
         
        
       /*  
         JLabel logintext=new JLabel("Login");
        logintext.setFont(new Font("Osward",Font.BOLD,20));
        logintext.setBounds(630,290,1000,100);
        add (logintext);
        */
        
        JLabel name=new JLabel("CNIC:");
        name.setFont(new Font("Osward",Font.BOLD,20));
        name.setBounds(350,230,1000,100);
        add (name);
        
        JTextField namef=new JTextField();
       namef.setBounds(460,270,210,25);
      // cnicf.setFont(new Font("Osward",Font.BOLD,18));
       add(namef);
        
        JLabel fname=new JLabel("Account Type:");
        fname.setFont(new Font("Osward",Font.BOLD,20));
        fname.setBounds(350,400,1000,100);
        add (fname);
        
        JTextField fnamef=new JTextField();
        
       fnamef.setBounds(530,400,210,25);
      // passwordf.setFont(new Font("Osward",Font.BOLD,18));
       add(fnamef);
       
       /*
       
     
       JLabel dob=new JLabel("Date of Birth:");
        dob.setFont(new Font("Osward",Font.BOLD,20));
        dob.setBounds(350,330,1000,100);
        add (dob);
        
        JLabel work=new JLabel("Profassion:");
        work.setFont(new Font("Osward",Font.BOLD,20));
        work.setBounds(730,230,1000,100);
        add (work);
        
        JLabel gander=new JLabel( "gander:");
        gander.setFont(new Font("Osward",Font.BOLD,20));
        gander.setBounds(730,280,1000,100);
        add (gander);
       
      */
        previous=new JButton("previous");
        previous.setBounds(480,475,150,30);
        previous.addActionListener(this);
        add(previous);
        
        next=new JButton("next");
        next.setBounds(650,475,150,30);
        next.addActionListener(this);
        add(next);

        
         JLabel rights=new JLabel("Copyright © 2023 All Rights Reserved");
         rights.setFont(new Font("Osward",Font.ITALIC,10));
        rights.setBounds(400,550,800,45);
        add (rights);

        
        
         getContentPane().setBackground(Color.WHITE);
        
        setSize(1375,750);
        setVisible(true);
        setLocation(0,0);
    }
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()== previous)
        {
            setVisible(false);
         new Login(); 
         
        }
        else if(false)
        {
            
        }
    }
    public static void main(String args[])
    {
       new SingnUp1(); 
    }
    
}
