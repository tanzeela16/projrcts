package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class AdditionalInfo extends JFrame  implements ActionListener{
     JTextField emailf,phonef,adressf;
     JComboBox educationf;
     JRadioButton married,unmarried,other;
    JButton previous,next;
    String formn;
    
   AdditionalInfo(String formn)
    {
        this.formn=formn;
       setTitle("Additional Information");
        
         setLayout(null);
         
         ImageIcon logo1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
         Image logo2=logo1.getImage().getScaledInstance(70,70,Image.SCALE_DEFAULT);
         ImageIcon logo3=new ImageIcon(logo2);
         JLabel logo4=new JLabel(logo3);
         logo4.setBounds(140,10,250,250);
         add(logo4);
         
        JLabel text=new JLabel("Master Bank");
        text.setFont(new Font("Osward",Font.BOLD,30));
        text.setBounds(310,80,1000,100);
        add (text);
        
        JLabel slogan =new JLabel("Master your finances with Bank Master");
        slogan.setFont(new Font("Osward",Font.ITALIC,7));
        slogan.setBounds(330,130,800,45);
        add (slogan);
        
        JLabel text2=new JLabel("Additional Details:");
        text2.setFont(new Font("Osward",Font.BOLD,20));
        text2.setBounds(500,150,1000,100);
        add (text2);
        
        
        
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/login.png"));
        Image i2=i1.getImage().getScaledInstance(25,25,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel label=new JLabel(i3);
        label.setBounds(470,190,25,25);
        add(label);
         
        JLabel email=new JLabel("Email:");
        email.setFont(new Font("Osward",Font.BOLD,20));
        email.setBounds(350,230,1000,100);
        add (email);
        
       emailf=new JTextField();
       emailf.setBounds(470,270,210,25);
       add(emailf);
        
        JLabel phone=new JLabel("Phone Num:");
        phone.setFont(new Font("Osward",Font.BOLD,20));
        phone.setBounds(350,280,1000,100);
        add (phone);
        
        phonef=new JTextField(); 
       phonef.setBounds(470,320,210,25);
       add(phonef);
       
        
       
       JLabel adress=new JLabel("Current Addres:");
        adress.setFont(new Font("Osward",Font.BOLD,20));
        adress.setBounds(730,280,300,100);
        add (adress);
        
        adressf=new JTextField();
        adressf.setBounds(900,320,300,25);
        add(adressf);
        
        
        JLabel education=new JLabel("Education:");
        education.setFont(new Font("Osward",Font.BOLD,20));
        education.setBounds(730,230,1000,100);
        add (education);
        
        String degree[] = {"Select", "Matric", "Inter", "Undergraduate", "Master", "PhD"};
        educationf = new JComboBox(degree);
educationf.setBackground(Color.WHITE);
educationf.setBounds(860, 265, 350, 25);
add(educationf);   
        
        JLabel gander=new JLabel( "Status:");
        gander.setFont(new Font("Osward",Font.BOLD,20));
        gander.setBounds(350,350,1000,100);
        add (gander);
       
        married=new JRadioButton("Married");
       married.setBounds(450,395,80,30);
       married.setBackground(Color.WHITE);
       add(married);
       
        unmarried=new JRadioButton("Unmrried");
       unmarried.setBounds(600,395,80,30);
       unmarried.setBackground(Color.WHITE);
       add(unmarried);
     
       other=new JRadioButton("Other");
       other.setBounds(450,430,80,30);
       other.setBackground(Color.WHITE);
       add(other);
    
        ButtonGroup GanderGroup=new ButtonGroup();
       GanderGroup.add(married);
       GanderGroup.add(unmarried);
       GanderGroup.add(other);
       
        previous=new JButton("previous");
        previous.setBounds(480,475,150,30);
        previous.addActionListener(this);
        add(previous);
        
        next=new JButton("next");
        next.setBounds(650,475,150,30);
        next.addActionListener(this);
        add(next);

        
         JLabel rights=new JLabel("Copyright © 2023 All Rights Reserved");
         rights.setFont(new Font("Osward",Font.ITALIC,10));
        rights.setBounds(400,550,800,45);
        add (rights);

        
        
         getContentPane().setBackground(Color.WHITE);
        
        setSize(1375,750);
        setVisible(true);
        setLocation(0,0);
    }
    public void actionPerformed(ActionEvent ae)
    {
        /*
        
         JTextField emailf,phonef,adressf;
     JComboBox education;
     JRadioButton married,unmarried,other;
        */
         if(ae.getSource()== next)
        {
        
        String formno=""+ formn;
        
        String email=emailf.getText();
        String phone=phonef.getText();
        String adress=adressf.getText();
        String seducation=(String)educationf.getSelectedItem();
        
        String status=null;
        
        if(married.isSelected())
        {
            status="Married";
        }
        else if(unmarried.isSelected())
        {
            status="Unmarried";
        }
        else if(other.isSelected())
        {
            status="Other";
        }
       
        
        try{
            if(email.equals("") ){
                JOptionPane.showMessageDialog(null, "Email is required ");
                
            }
            else  if(phone.equals("") ){
                JOptionPane.showMessageDialog(null, "Phone No: is required ");
                
            }
             else  if(adress.equals("") ){
                JOptionPane.showMessageDialog(null, "Adress is required ");
                
            }
              else  if(seducation.equals("") ){
                JOptionPane.showMessageDialog(null, "Select Your Degree ");
                
            }
               else  if(status.equals("") ){
                JOptionPane.showMessageDialog(null, "Select Your Status");
                
            }
              
            else
            {
                Conn c=new Conn();
                
               String query="insert into AdditionalInfo values ('"+formno+"','"+email+"', '"+phone+"', '"+adress+"', '"+seducation+"','"+status+"')";
                
                c.s.executeUpdate(query);
                
                setVisible(false);
                
                new AccountDetails(formn).setVisible(true);
                
                        
            }
        }catch(Exception e)
        {
            System.out.println(e);
        }
        /*
        if(ae.getSource()== previous)
        {
            setVisible(false);
         new SingnUp(); 
         
        }
        else if(ae.getSource()== next)
        {
            setVisible(false);
         new AccountDetails(); 
            
        }
*/
        }
          else if(ae.getSource()== previous)
        {
            setVisible(false);
         new SingnUp().setVisible(true); 
            
        }
    }
    public static void main(String args[])
    {
       new AdditionalInfo(""); 
    }
    
}
