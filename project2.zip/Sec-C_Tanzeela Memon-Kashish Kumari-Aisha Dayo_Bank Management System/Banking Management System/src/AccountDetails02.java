
package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import com.toedter.calendar.JDateChooser;

public class AccountDetails02 extends JFrame implements ActionListener { 
    

   JDateChooser dateChooser;
   JTextField amountf;
    JButton cancel,creat;
    JRadioButton Asan,Saving,current,Student;
    String formno;
    
    
        AccountDetails02(String formno)
                {
                    this.formno=formno;
                    
                   setTitle("AccountsDetails02");
        
         setLayout(null);
         
         ImageIcon logo1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
         Image logo2=logo1.getImage().getScaledInstance(70,70,Image.SCALE_DEFAULT);
         ImageIcon logo3=new ImageIcon(logo2);
         JLabel logo4=new JLabel(logo3);
         logo4.setBounds(140,10,250,250);
         add(logo4);
         
        JLabel text=new JLabel("Master Bank");
        text.setFont(new Font("Osward",Font.BOLD,30));
        text.setBounds(310,80,1000,100);
        add (text);
        
        JLabel slogan =new JLabel("Master your finances with Bank Master");
        slogan.setFont(new Font("Osward",Font.ITALIC,7));
        slogan.setBounds(330,130,800,45);
        add (slogan);
        
        JLabel text2=new JLabel("Account Details:");
        text2.setFont(new Font("Osward",Font.BOLD,20));
        text2.setBounds(500,150,1000,100);
        add (text2);
        
        
        
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/login.png"));
        Image i2=i1.getImage().getScaledInstance(25,25,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel label=new JLabel(i3);
        label.setBounds(470,190,25,25);
        add(label);
         
        JLabel caption =new JLabel("let's your Digital banking with us , and tranfer your money on a just finger tip.");
        caption.setFont(new Font("Osward",Font.ITALIC,15));
        caption.setBounds(360,230,800,45);
        add (caption);
        
        JLabel date=new JLabel("Request Date:");
        date.setFont(new Font("Osward",Font.BOLD,20));
        date.setBounds(350,270,200,50);
        add (date);
        
        dateChooser=new JDateChooser();
        dateChooser.setBounds(500,280,300,25);
        add(dateChooser);
        
        JLabel amount=new JLabel("Branch:");
        amount.setFont(new Font("Osward",Font.BOLD,20));
        amount.setBounds(350,310,300,50);
        add (amount);
        
        amountf=new JTextField();
        amountf.setBounds(550,320,250,25);
        add(amountf);
        
        JLabel fname=new JLabel("Account Type:");
        fname.setFont(new Font("Osward",Font.BOLD,20));
        fname.setBounds(350,320,1000,100);
        add (fname);
        
       Asan=new JRadioButton("Asaan Acount");
       Asan.setBounds(550,360,130,30);
       Asan.setBackground(Color.WHITE);
       add(Asan);
       
        Saving=new JRadioButton("Saving Account");
       Saving.setBounds(700,360,130,30);
       Saving.setBackground(Color.WHITE);
       add(Saving);
       
     
       current=new JRadioButton("Current Account");
       current.setBounds(550,400,130,30);
       current.setBackground(Color.WHITE);
       add(current);
       
        Student=new JRadioButton("Student Account");
       Student.setBounds(700,400,130,30);
       Student.setBackground(Color.WHITE);
       add(Student);
    
       ButtonGroup AccountTypeGroup=new ButtonGroup();
       AccountTypeGroup.add(Asan);
       AccountTypeGroup.add(Saving);
       AccountTypeGroup.add(current);  
       AccountTypeGroup.add(Student);
              
              
              
        cancel=new JButton("previous");
       cancel.setBounds(480,475,150,30);
        cancel.addActionListener(this);
        add(cancel);
        
        creat=new JButton("Creat");
        creat.setBounds(650,475,150,30);
        creat.addActionListener(this);
        add(creat);

        
         JLabel rights=new JLabel("Copyright © 2023 All Rights Reserved");
         rights.setFont(new Font("Osward",Font.ITALIC,10));
        rights.setBounds(400,550,800,45);
        add (rights);

        
        
         getContentPane().setBackground(Color.WHITE);
         
         
        setSize(1375,750);
        setVisible(true);
        setLocation(0,0); 
                }
   @Override
    public void actionPerformed(ActionEvent ae)
    {
          
        if(ae.getSource()== creat)
        {
         String formn=""+ formno;
       
        // String date="khan sahab";
          String date =((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
        // date = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
       String amount=amountf.getText();
       
       
        String accT=null;
        
        if(Asan.isSelected())
        {
           accT="Assan Account"; 
        }
        else if(Saving.isSelected())
        {
           accT="Saving Account"; 
        }
        else if(current.isSelected())
        {
           accT="Current Account"; 
        }
        else if(Student.isSelected())
        {
           accT="Student Account"; 
        }
        
        Random random = new Random();
        
        String cardnumber=" "+Math.abs((random.nextLong()%90000000L)+504093600000000L);
        
        String pinnumber=""+Math.abs((random.nextLong()%9000L)+1000L);
        
        try{
            if(date.equals("")){
                JOptionPane.showMessageDialog(null, "Date is required ");
                
            }
             if(accT.equals(null)){
                JOptionPane.showMessageDialog(null, "Select acount type ");
                
            }
             
            else
            {
                Conn c=new Conn();
                
               String query1="insert into accountdetails values ('"+formn+"','"+date+"', '"+amount+"','"+accT+"','"+cardnumber+"','"+pinnumber+"')";
                String query2="insert into login values ('"+formn+"','"+cardnumber+"','"+pinnumber+"')";
               
                
               c.s.executeUpdate(query1);
                 c.s.executeUpdate(query2);
                 
                JOptionPane.showMessageDialog(null, "Card Number: " + cardnumber + "\n Pin:"+ pinnumber);
                
                setVisible(false);
                new Deposite(pinnumber).setVisible(true);
                //new Login().setVisible(true);
                
            }
        }catch(Exception e)
        {
            System.out.println(e);
        }
        
        
/*        
        if(ae.getSource()== previous)
        {
            setVisible(false);
              new Login(); 
         
        }
        else if(ae.getSource()== next)
        {
            setVisible(false);
            new SingnUp();
        }
        */

        }
         else if(ae.getSource()== cancel)
        {
            setVisible(false);
            new Login();
        }
    }
    public static void main(String args[])
    {
       new AccountDetails02("");   
    }

   // private void add(JDateChooser dateChooser) {
    //    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    //}

  //private static class JDateChooser {

       // public JDateChooser() {
       // }

     //   private void setBounds(int i, int i0, int i1, int i2) {
       //     throw new UnsupportedOperationException("Not supported yet."); 
       // }

       // private Object getDateEditor() {
        //    throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
      //  }
   // }
}
