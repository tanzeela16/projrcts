package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.toedter.calendar.JDateChooser;
import java.util.*;
import java.sql.*;

public class Transections extends JFrame implements ActionListener {
    JButton Deposite,withdra,ministatement,pinchange,ballance,exite;
    String pinnumber;
    
    String pin;
    String formn;
    
    Transections(String pinnumber )
    {
        this.pinnumber=pinnumber;        setTitle("Transection Portal");
        
         setLayout(null);
         
         ImageIcon logo1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.png"));
         Image logo2=logo1.getImage().getScaledInstance(70,70,Image.SCALE_DEFAULT);
         ImageIcon logo3=new ImageIcon(logo2);
         JLabel logo4=new JLabel(logo3);
         logo4.setBounds(140,10,250,250);
         add(logo4);
         
        JLabel text=new JLabel("Master Bank");
        text.setFont(new Font("Osward",Font.BOLD,30));
        text.setBounds(310,80,1000,100);
        add (text);
        
        JLabel slogan =new JLabel("Master your finances with Bank Master");
        slogan.setFont(new Font("Osward",Font.ITALIC,7));
        slogan.setBounds(330,130,800,45);
        add (slogan);
        
         JLabel transection = new JLabel("Please Select Your Transaction");
        transection.setFont(new Font("Osward",Font.BOLD,20));
        transection.setBounds(500,175,300,50);
        add(transection);
        
        JLabel name = new JLabel();
        name.setFont(new Font("Osward",Font.BOLD,20));
        name.setBounds(550,220,800,50);
        add(name);
        
        try{
            Conn conn=new Conn( );
            ResultSet rs=conn.s.executeQuery("select * from login where pin='"+pinnumber+"'");
            
            while(rs.next())
            {
                formn=(rs.getString("formno"));
            }
        }
         catch(Exception e)
        {
            System.out.println(e);
        }
        
         try{
            Conn conn=new Conn( );
            ResultSet rs=conn.s.executeQuery("select * from SingnUp where formno='"+formn+"'");
            
            while(rs.next())
            {
                name.setText("Name: "+rs.getString("namef"));
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        Deposite=new JButton("Deposite");
        Deposite.setBounds(500,300,150,30);
        Deposite.addActionListener(this);
        add(Deposite);
        
     withdra=new JButton("Withdraw");
        withdra.setBounds(730,300,150,30);
        withdra.addActionListener(this);
        add(withdra);
        
          ministatement=new JButton("Mini Statement");
        ministatement.setBounds(500,350,150,30);
        ministatement.addActionListener(this);
        add(ministatement);
        
         pinchange=new JButton("Pin Change");
        pinchange.setBounds(730,350,150,30);
        pinchange.addActionListener(this);
        add(pinchange);
        
        ballance =new JButton("BALLANCE INQUIRE");
        ballance.setBounds(500,400,150,30);
        ballance.addActionListener(this);
        add(ballance);
        
      exite=new JButton("Log Out");
        exite.setBounds(730,400,150,30);
        exite.addActionListener(this);
        add(exite);
       
       
        getContentPane().setBackground(Color.WHITE);
         
         
        setSize(1375,750);
        setVisible(true);
        setLocation(0,0); 
        
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==Deposite)
        {
            setVisible(false);
           new Deposite02(pinnumber).setVisible(true);
           
            
            
        }
        else if(ae.getSource()==withdra)
        {
            setVisible(false);
            new Withdraw(pinnumber).setVisible(true);
        }
        
        else if(ae.getSource()==pinchange)
        {
            setVisible(false);
            new PinChange(pinnumber).setVisible(true);
        }
        
        else if(ae.getSource()==ballance)
        {
            setVisible(false);
            new BalanceEnquiry(pinnumber).setVisible(true);
        }
         else if(ae.getSource()==ministatement)
        {
            setVisible(false);
            new MiniStatement(pinnumber).setVisible(true);
        }
       
        else if(ae.getSource()== exite)
        {
            setVisible(false);
            new Login();
        }
  
    }
    public static void main(String args[])
    {
        new Transections("");
    }
    
}
