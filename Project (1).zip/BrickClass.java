import brickbreaker.*;

import javax.swing.*;

public class BrickClass extends JFrame {
	
	public BrickClass(){
        JFrame f1 = new JFrame();
        PlayGame obj = new PlayGame();
        f1.setBounds(10, 10, 707, 610);
        f1.setTitle("BrickBreaker Game");
        f1.setResizable(false);
        f1.setVisible(true);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.add(obj);

	
	
	}
	
    }
   

