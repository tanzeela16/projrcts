import GAME.*;
import brickbreaker.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class MainClass implements ActionListener{

	JFrame f;
	JPanel p;
	JLabel l,l2;
	JButton b,b2;
	ImageIcon icon = new ImageIcon("snake2.jpg");
	

	public void method(){
	
	f = new JFrame("Games");
	p = new JPanel();
	
   
	l = new JLabel("", icon, JLabel.CENTER);
	l.setBounds(0,0,800,525);

	l2 = new JLabel("WHICH GAME YOU WANT TO PLAY?");
        l2.setBounds(20,8,750,50);
        l2.setFont(new Font("SHOWCARD GOTHIC", Font.BOLD, 43));
	l2.setForeground(Color.white);

	

	b = new JButton("Snake");
        b.setBounds(550,450,120,40);
        b.addActionListener(this);
	b.setFont(new Font("Ink Free", Font.BOLD, 32));
	b.setBackground(Color.gray);
	b.setForeground(Color.white);
	b.setBorderPainted(true);
	b.setOpaque(true);



	b2 = new JButton("BrickBreaker");
        b2.setBounds(50,430,230,40);
        b2.addActionListener(this);
	b2.setFont(new Font("Ink Free", Font.BOLD, 32));
	b2.setBackground(Color.gray);
	b2.setForeground(Color.white);
	b2.setBorderPainted(true);
	b2.setOpaque(true);

	

	f.add(l);
	f.setSize(800,525);
	l.add(l2);
	l.add(b);
	l.add(b2);
	
	f.setLayout(null);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	f.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent a){
	if(a.getSource() == b){
	
	 SnakeFrame s = new SnakeFrame();


		}

	 if(a.getSource() == b2){
		
		
		BrickClass m = new BrickClass();		
}


}

public static void main (String args[]){

	MainClass np = new MainClass();
	np.method();
	}


}
